//INDICE (main)
const express = require('express');     //libreria per utilizzare metodi HTTP e URL
const axios = require("axios");
const cheerio = require('cheerio');

var app = express();                  //istanzio la libreria

app.use(express.static('public'));

app.get("/cities", function(req, res) { //per l'interazione client server 
	Promise.all([                       //prelevo i dati da Altervista
		axios.get("http://meneguzzi.altervista.org/citta.html"),
		axios.get("http://meneguzzi.altervista.org/tipodiposto.html")
	]).then((htmlResults) => {
		const citiesHtml = htmlResults[0].data;
		const placesHtml =  htmlResults[1].data;

		let cities = scrapeFirstRow(citiesHtml);
		let places = scrapeFirstRow(placesHtml);

		let result = [];
		let promises = [];
		cities.forEach((cityName) => {
			let jsonCity = {
				name: cityName,
				value: cityName.toLowerCase(),
				backgroundImage: cityName.toLowerCase() + ".jpg"   //sfondi variabili
			}
			places.forEach((placeName) => {
				promises.push(getAllLocations(cityName, placeName).then((response) => {
					jsonCity[placeName.toLowerCase()] = response;
				}));
			})
			result.push(jsonCity);
		});

		Promise.all(promises).then(() => {
			setTimeout(() => res.send(result), 1500); //Pur facendo le richieste http, ci mettiamo troppo poco tempo a caricare. Aggiungiamo un poì di delay artificiale per far vedere il loader
		});
	})
})

function scrapeFirstRow(html) {
	const result = [];
	const $ = cheerio.load(html);
	$("table td:nth-child(1)").each(function() {
		result.push($(this).text()) 
	});
	return result;
}

async function getAllLocations(city, place) {
	let locationHTML = await axios.get("http://meneguzzi.altervista.org/" + place + city + ".html");
	let locations = []
	const $ = cheerio.load(locationHTML.data);
	$("table tr").each(function() {
		let location = {
			name : $(this).find("td:nth-child(1)").text().replace("\n", ""),
			link : $(this).find("td:nth-child(4)").text().replace("\n", ""),
		}
		locations.push(location);
	});
	return locations
}

// NAPOLI:
// http://meneguzzi.altervista.org/MuseiNapoli.html 
// http://meneguzzi.altervista.org/RistorantiNapoli.html
// http://meneguzzi.altervista.org/AttivitaNapoli.html
// MILANO:
// http://meneguzzi.altervista.org/AttivitaMilano.html
// http://meneguzzi.altervista.org/MuseiMulano.html
// http://meneguzzi.altervista.org/RistorantiMilano.html
// FIRENZE
// http://meneguzzi.altervista.org/RistorantiFirenze.html
// http://meneguzzi.altervista.org/AttivitaFirenze.html
// http://meneguzzi.altervista.org/MuseiFirenze.html
// ROMA:
// http://meneguzzi.altervista.org/MuseiRoma.html
// http://meneguzzi.altervista.org/RistorantiRoma.html
// http://meneguzzi.altervista.org/AttivitaRoma.html

app.listen(3000, function () {          //server in ascolto alla porta 3000
  console.log('Cultrip on port 3000 !');
});