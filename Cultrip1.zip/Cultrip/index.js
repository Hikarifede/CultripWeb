//INDICE (main)
var express = require('express');     //libreria per utilizzare metodi HTTP e URL
var app = express();
const path = require("path")         //per l'accesso alle varie cartelle ('bin, img, nodejs...)

app.use(express.static('public'));

app.get("/cities", function(req, res) { //per l'interazione client server 
    setTimeout(() => {                  //attesa di 2 secondi al caricamento
        res.sendFile(path.join(__dirname, 'database.json')); //risposta
    }, 2000);
})

app.listen(3000, function () {          //server in ascolto al porto 3000
  console.log('Cultrip sta girando al porto 3000!');
});