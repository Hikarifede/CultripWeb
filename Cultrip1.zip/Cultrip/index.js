//INDICE (main)
var express = require('express');     //libreria per utilizzare metodi HTTP e URL
const path = require("path")         //libreria per la concatenazione di path di sistema

var app = express();                  //istanzio la libreria

app.use(express.static('public'));

app.get("/cities", function(req, res) { //per l'interazione client server 
    setTimeout(() => {                  //attesa di 2 secondi al caricamento
        res.sendFile(path.join(__dirname, 'database.json')); //risposta
    }, 2000);
})

app.listen(3000, function () {          //server in ascolto alla porta 3000
  console.log('Cultrip on port 3000 !');
});