
var app = new Vue({   //istanzio l'oggetto di vue
    el: '#app',       //collego vue all'oggetto HTML con id App

    created() {
        this.loading = true;
        axios
            .get("/cities")
            .then(response => {
                this.cities = response.data;
                this.selectedCity = this.cities[0].value;
                this.selectedPlaceType = "musei";
            })
            .finally(() => this.loading = false)
        ;
    },

    data: {             //inizializzo le variabili
        cities : [],
        selectedCity : null,
        selectedPlaceType : null,
        loading: false
    },

    computed : {                //tutte le variabili dinamiche
        currentCity() {
            if (this.selectedCity) {
                return this.cities.find((item) => item.value === this.selectedCity);
            } else {
                return null;
            }
        },
  
        backgroundImage() {
            if (this.currentCity) {
                return this.currentCity.backgroundImage
            } else {
                return "sfondo.jpg"
            }
        },

        placesList() {
            if (this.currentCity == null) {
                return [];
            }
            return this.currentCity[this.selectedPlaceType];
        }

    }


})