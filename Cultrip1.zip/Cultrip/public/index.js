

var app = new Vue({
    el: '#app',

    created() {
        this.loading = true;
        axios
            .get("/cities")
            .then(response => {
                this.cities = response.data;
                this.selectedCity = this.cities[0].value;
            })
            .finally(() => this.loading = false)
        ;
    },

    data: {
        cities : [],
        selectedCity : null,
        loading: false
    },

    computed : {
        currentCity() {
            if (this.selectedCity) {
                return this.cities.find((item) => item.value === this.selectedCity);
            } else {
                return null;
            }
        },

        
        backgroundImage() {
            if (this.currentCity) {
                return this.currentCity.backgroundImage
            } else {
                return "sfondo.jpg"
            }
        }
    },


})